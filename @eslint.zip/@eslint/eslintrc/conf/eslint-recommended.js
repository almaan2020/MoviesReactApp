/**
 * @fileoverview Stub eslint:recommended config
 * @author Nicholas C. Zakas
 */

"use strict";

module.exports = {
    settings: {
        "eslint:recommended": true
    }
};
